package com.techway.coursemanagementdesktop.controller;

import com.techway.coursemanagementdesktop.model.Course;
import com.techway.coursemanagementdesktop.model.Lesson;
import com.techway.coursemanagementdesktop.service.ApiService;
import com.techway.coursemanagementdesktop.util.SessionManager;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import okhttp3.HttpUrl;

import java.awt.*;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.*;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import javafx.scene.paint.Color;


public class CourseDetailsPageController {

    private static final String API_BASE = "http://localhost:8080";
    private final MainController mainController;
    private final SessionManager sessionManager;

    /** كاش بسيط للصور */
    private final Map<String, Image> imageCache = new ConcurrentHashMap<>();
    private Long enrollmentId;

    public CourseDetailsPageController(MainController mainController, SessionManager sessionManager) {
        this.mainController = mainController;
        this.sessionManager = sessionManager;
    }

    /* =============================== UI =============================== */

    /** يبني صفحة التفاصيل */
    public VBox createCourseDetailsPage(Course course) {
        VBox root = new VBox(16);
        root.getStyleClass().add("details-page");
        root.setPadding(new Insets(24));

        // رجوع
        Hyperlink back = new Hyperlink("⬅ العودة");
        back.getStyleClass().add("back-link");
        back.setOnAction(e -> mainController.navigateToCourses());
        root.getChildren().add(back);

        // شبكة عمودين
        GridPane grid = new GridPane();
        grid.setHgap(24);
        grid.setVgap(24);
        ColumnConstraints left = new ColumnConstraints();
        left.setPrefWidth(320);
        left.setMinWidth(280);
        ColumnConstraints right = new ColumnConstraints();
        right.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(left, right);

        /* ===== العمود الأيمن: هيدر وصورة وميتا وأقسام ===== */
        VBox rightCol = new VBox(16);

        // هيرو
        StackPane hero = new StackPane();
        hero.getStyleClass().add("details-hero");
        hero.setMinHeight(260);
        hero.setPrefHeight(260);

        Rectangle clip = new Rectangle();
        clip.setArcWidth(20);
        clip.setArcHeight(20);
        hero.layoutBoundsProperty().addListener((obs, o, b) -> {
            clip.setWidth(b.getWidth());
            clip.setHeight(b.getHeight());
        });
        hero.setClip(clip);

        ImageView heroImage = new ImageView();
        heroImage.setPreserveRatio(false);
        heroImage.setSmooth(true);
        heroImage.fitWidthProperty().bind(hero.widthProperty());
        heroImage.fitHeightProperty().bind(hero.heightProperty());
        loadCourseImage(heroImage, getString(course, "getImageUrl"));

        boolean isFree = Boolean.TRUE.equals(getBoolean(course, "getIsFree"));
        Label badge = new Label(isFree ? "مجاني" : "مدفوع");
        badge.getStyleClass().add("chip");
        StackPane.setAlignment(badge, Pos.TOP_RIGHT);
        StackPane.setMargin(badge, new Insets(12));

        hero.getChildren().addAll(heroImage, badge);

        // العنوان
        String titleStr = or(
                getString(course, "getTitle"),
                "Course Title"
        );
        Label title = new Label(titleStr);
        title.getStyleClass().add("details-title");
        title.setWrapText(true);

        // ميتا
        HBox meta = new HBox(18);
        meta.setAlignment(Pos.CENTER_LEFT);
        meta.getChildren().addAll(
                metaItem("⭐", ratingText(course)),
                metaItem("⏱", durationText(course)),
                metaItem("📍", or(getString(course, "getLocationDisplay"), "—")),
                metaItem("👤", or(getString(course, "getInstructor"), "—"))
        );

        rightCol.getChildren().addAll(hero, title, meta);

        // وصف
        rightCol.getChildren().add(sectionCard(
                "وصف الكورس",
                or(
                        getString(course, "getLongDescription"),
                        getString(course, "getDescription"),
                        getString(course, "getShortDescription"),
                        "لا توجد بيانات متاحة حالياً."
                )
        ));

        // ما ستتعلمه
        rightCol.getChildren().add(listSection("ما ستتعلمه:", learningList(course)));

        // المتطلبات
        rightCol.getChildren().add(listSection("المتطلبات:", requirementsList(course)));

        // المحتوى
        rightCol.getChildren().add(syllabusSection("محتوى الكورس:", syllabusList(course)));
        rightCol.getChildren().add(lessonsSection(course,enrollmentId));


        /* ===== العمود الأيسر: بطاقة التسجيل + معلومات سريعة ===== */
        VBox leftCol = new VBox(16);

        VBox purchase = new VBox(12);
        purchase.getStyleClass().add("purchase-card");
        purchase.setPadding(new Insets(16));

        Label price = new Label(priceText(course));
        price.getStyleClass().add("price-amount");

        Button enroll = new Button(isFree ? "التسجيل المجاني" : "التسجيل في الكورس");
        enroll.getStyleClass().add("primary-button");
        enroll.setMaxWidth(Double.MAX_VALUE);

        enroll.setOnAction(e -> {
            if (!sessionManager.isLoggedIn()) {
                mainController.navigateToLogin();
                return;
            }

            Long userId = sessionManager.getCurrentUserId();
            Long courseId = course.getId();

            ApiService.getInstance().enrollUser2(userId, courseId)
                    .thenAccept(enrollment -> {
                        Platform.runLater(() -> {
                            Alert a = new Alert(Alert.AlertType.INFORMATION,
                                    "تم تسجيلك في الكورس: " + enrollment.getCourseTitle(),
                                    ButtonType.OK);
                            a.setHeaderText("تم التسجيل بنجاح ✅");
                            a.showAndWait();
                        });
                    })
                    .exceptionally(ex -> {
                        Platform.runLater(() -> {
                            Alert error = new Alert(Alert.AlertType.ERROR,
                                    "فشل التسجيل: " + ex.getMessage(),
                                    ButtonType.OK);
                            error.setHeaderText("خطأ");
                            error.showAndWait();
                        });
                        return null;
                    });
        });

        HBox quick = new HBox(8);
        quick.setAlignment(Pos.CENTER);
        Button save = new Button("♡ حفظ");
        save.getStyleClass().add("ghost-button");
        Button share = new Button("↗ مشاركة");
        share.getStyleClass().add("ghost-button");
        HBox.setHgrow(save, Priority.ALWAYS);
        HBox.setHgrow(share, Priority.ALWAYS);
        save.setMaxWidth(Double.MAX_VALUE);
        share.setMaxWidth(Double.MAX_VALUE);
        quick.getChildren().addAll(share, save);

        purchase.getChildren().addAll(price, enroll, quick);

        VBox facts = new VBox(8);
        facts.getStyleClass().add("info-card");
        facts.setPadding(new Insets(12));
        facts.getChildren().addAll(
                factRow("المدة", durationText(course)),
                factRow("الموقع", or(getString(course, "getLocationDisplay"), "—")),
                factRow("حالة الكورس", or(getString(course, "getStatus"), "—"))
        );

        leftCol.getChildren().addAll(purchase, facts);

        // ضع في الشبكة
        grid.add(leftCol, 0, 0);
        grid.add(rightCol, 1, 0);

        root.getChildren().add(grid);
        return root;
    }

    private VBox lessonsSection(Course course, Long enrollmentId) {
        VBox box = new VBox(12);
        box.getStyleClass().add("section-card");
        box.setPadding(new Insets(16));

        Label title = new Label("محتوى المسار");
        title.getStyleClass().add("section-title");

        VBox lessonsList = new VBox(12);

        ApiService.getInstance().getLessonsForCourse(course.getId())
                .thenAccept(lessons -> {
                    Platform.runLater(() -> {
                        for (Map<String, Object> map : lessons) {
                            Lesson lesson = new Lesson();
                            lesson.setTitle((String) map.get("title"));
                            lesson.setVideoUrl((String) map.get("videoUrl"));
                            lesson.setId(((Number) map.get("id")).longValue());

                            // يمكنك أيضًا إضافة:
                            // lesson.setId( ((Number) map.get("id")).longValue() );
                            // lesson.setOrderIndex( ((Number) map.get("orderIndex")).intValue() );

                            lessonsList.getChildren().add(createLessonCard(lesson,enrollmentId));
                        }
                    });
                })
                .exceptionally(ex -> {
                    Platform.runLater(() -> {
                        Label error = new Label("فشل تحميل الدروس ❌");
                        lessonsList.getChildren().add(error);
                    });
                    return null;
                });


        box.getChildren().addAll(title, lessonsList);
        return box;
    }

    private HBox createLessonCard(Lesson lesson, Long enrollmentId) {
        HBox card = new HBox(12);
        card.getStyleClass().add("lesson-card");
        card.setPadding(new Insets(12));
        card.setStyle("-fx-background-color: #2c2c54; -fx-background-radius: 12;");

        Label title = new Label(lesson.getTitle());
        title.getStyleClass().add("lesson-title");
        title.setTextFill(Color.WHITE);

        Hyperlink videoLink = new Hyperlink("تشغيل الفيديو");
        videoLink.setOnAction(e -> {
            openVideo(lesson.getVideoUrl());

            // ✅ سجل التقدم في الباك اند
            ApiService.getInstance().markLessonAsCompleted(enrollmentId, lesson.getId());
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        card.getChildren().addAll(title, videoLink, spacer);
        return card;
    }


    private void openVideo(String url) {
        if (url == null || url.isBlank()) {
            mainController.showError("رابط الفيديو غير صالح.");
            return;
        }

        Platform.runLater(() -> {
            if (url.contains("youtube.com") || url.contains("youtu.be")) {
                // YouTube link
                String videoId = extractYoutubeVideoId(url);
                if (videoId == null) {
                    mainController.showError("تعذر استخراج معرف الفيديو من رابط YouTube.");
                    return;
                }

                Stage stage = new Stage();
                stage.setTitle("تشغيل الفيديو - YouTube");

                WebView webView = new WebView();
                WebEngine webEngine = webView.getEngine();

                String content = buildYoutubeEmbedHtml(videoId);
                webEngine.loadContent(content);

                Scene scene = new Scene(webView, 800, 480);
                stage.setScene(scene);
                stage.show();
            } else {
                // أي رابط فيديو عادي (mp4، m3u8، رابط مباشر...)
                try {
                    Desktop.getDesktop().browse(new URI(url));
                } catch (Exception ex) {
                    mainController.showError("تعذر فتح رابط الفيديو في المتصفح.");
                }
            }
        });
    }

    private String buildYoutubeEmbedHtml(String videoId) {
        return """
        <html>
        <head>
            <style>
                body, html {
                    margin: 0;
                    padding: 0;
                    height: 100%%;
                    background-color: black;
                }
                iframe {
                    width: 100%%;
                    height: 100%%;
                    border: none;
                }
            </style>
        </head>
        <body>
            <iframe 
                src="https://www.youtube.com/embed/%s?autoplay=1&rel=0&modestbranding=1&controls=1" 
                allow="autoplay; encrypted-media" 
                allowfullscreen>
            </iframe>
        </body>
        </html>
        """.formatted(videoId);
    }


    // استخراج معرف الفيديو من رابط YouTube
    private String extractYoutubeVideoId(String url) {
        try {
            URI uri = new URI(url);
            String host = uri.getHost();
            if (host == null) return null;

            if (host.contains("youtu.be")) {
                return uri.getPath().substring(1);  // بعد /
            } else if (host.contains("youtube.com")) {
                String query = uri.getQuery();
                if (query != null) {
                    for (String param : query.split("&")) {
                        if (param.startsWith("v=")) {
                            return param.substring(2);
                        }
                    }
                }

                // ممكن يكون الرابط بصيغة /embed/{id}
                String path = uri.getPath();
                if (path.startsWith("/embed/")) {
                    return path.substring(7);
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }





    /* =============================== Helpers: UI blocks =============================== */

    private Node metaItem(String icon, String text) {
        HBox box = new HBox(6);
        Label i = new Label(icon);
        Label t = new Label(text);
        i.getStyleClass().add("meta-icon");
        t.getStyleClass().add("meta-text");
        box.getChildren().addAll(i, t);
        return box;
    }

    private VBox sectionCard(String title, String bodyText) {
        VBox card = new VBox(10);
        card.getStyleClass().add("section-card");
        card.setPadding(new Insets(16));
        Label t = new Label(title);
        t.getStyleClass().add("section-title");
        Label b = new Label(bodyText);
        b.setWrapText(true);
        b.getStyleClass().add("section-body");
        card.getChildren().addAll(t, b);
        return card;
    }

    private VBox listSection(String title, List<String> items) {
        VBox card = new VBox(12);
        card.getStyleClass().add("section-card");
        card.setPadding(new Insets(16));
        Label t = new Label(title);
        t.getStyleClass().add("section-title");

        VBox list = new VBox(6);
        for (String s : items) {
            HBox row = new HBox(8);
            Label dot = new Label("•");
            dot.getStyleClass().add("bullet");
            Label txt = new Label(s);
            txt.setWrapText(true);
            txt.getStyleClass().add("section-body");
            row.getChildren().addAll(dot, txt);
            list.getChildren().add(row);
        }
        card.getChildren().addAll(t, list);
        return card;
    }

    private VBox syllabusSection(String title, List<String> modules) {
        VBox card = new VBox(12);
        card.getStyleClass().add("section-card");
        card.setPadding(new Insets(16));
        Label t = new Label(title);
        t.getStyleClass().add("section-title");

        Accordion acc = new Accordion();
        int idx = 1;
        for (String m : modules) {
            VBox content = new VBox(6);
            content.setPadding(new Insets(10));
            Label l = new Label(m);
            l.setWrapText(true);
            l.getStyleClass().add("section-body");
            content.getChildren().add(l);
            TitledPane tp = new TitledPane("الوحدة " + idx++, content);
            tp.getStyleClass().add("syllabus-pane");
            acc.getPanes().add(tp);
        }
        if (!acc.getPanes().isEmpty()) acc.setExpandedPane(acc.getPanes().get(0));

        card.getChildren().addAll(t, acc);
        return card;
    }

    private HBox factRow(String key, String val) {
        HBox row = new HBox(8);
        Label k = new Label(key + ":");
        k.getStyleClass().add("fact-key");
        Label v = new Label(val);
        v.getStyleClass().add("fact-val");
        row.getChildren().addAll(k, v);
        return row;
    }

    /* =============================== Text builders (safe) =============================== */

    private String priceText(Course c) {
        if (c == null) return "—";
        Boolean free = getBoolean(c, "getIsFree");
        if (Boolean.TRUE.equals(free)) return "مجاني";
        String pDisp = getString(c, "getPriceDisplay");
        if (pDisp != null && !pDisp.isBlank()) return pDisp;
        Number pNum = getNumber(c, "getPrice");
        return pNum != null ? pNum + " ريال" : "—";
    }

    private String ratingText(Course c) {
        Number r = getNumber(c, "getRating");
        Number cnt = getNumber(c, "getRatingCount");
        if (r == null && cnt == null) return "—";
        String rr = r != null ? String.format(java.util.Locale.US, "%.1f", r.doubleValue()) : "—";
        String cc = cnt != null ? "(" + cnt.intValue() + " تقييم)" : "";
        return rr + " " + cc;
    }

    private String durationText(Course c) {
        Number h = getNumber(c, "getDuration");
        return h != null ? (h.intValue() + " ساعة") : "—";
    }


    private List<String> learningList(Course c) {
        List<String> out = getStringList(c, "getLearningOutcomes");
        if (out == null || out.isEmpty()) {
            out = new ArrayList<>();
            out.add("مهارات عملية مطلوبة في سوق العمل.");
            out.add("مشروع تطبيقي لبناء أعمال قوية.");
            out.add("أساسيات ثم مفاهيم متقدمة بشكل تدريجي.");
        }
        return out;
    }

    private List<String> requirementsList(Course c) {
        List<String> out = getStringList(c, "getRequirements");
        if (out == null || out.isEmpty()) {
            out = new ArrayList<>();
            out.add("جهاز كمبيوتر واتصال إنترنت مستقر.");
            out.add("الرغبة في التعلم والممارسة.");
        }
        return out;
    }

    private List<String> syllabusList(Course c) {
        String syl = getString(c, "getSyllabus");
        List<String> out = new ArrayList<>();
        if (syl != null && !syl.isBlank()) {
            String[] lines = syl.split("\\r?\\n");
            for (String ln : lines) {
                String s = ln.trim();
                if (!s.isBlank()) out.add(s);
            }
        }
        if (out.isEmpty()) {
            out.add("مقدمة وأساسيات الموضوع.");
            out.add("الأدوات والمتطلبات المطلوبة.");
            out.add("التطبيق العملي والأمثلة.");
        }
        return out;
    }

    /* =============================== Images =============================== */

    private void loadCourseImage(ImageView imageView, String imageUrl) {
        String normalized = normalizeUrl(imageUrl);
        if (normalized == null) {
            setDefaultCourseImage(imageView);
            return;
        }
        Image cached = imageCache.get(normalized);
        if (cached != null) { imageView.setImage(cached); return; }

        try {
            Image img = new Image(normalized, 1280, 720, false, true, true);
            imageView.setImage(img);
            img.errorProperty().addListener((o, w, e) -> { if (e) setDefaultCourseImage(imageView); });
            img.progressProperty().addListener((o, a, b) -> {
                if (b != null && b.doubleValue() >= 1.0 && !img.isError()) imageCache.putIfAbsent(normalized, img);
            });
        } catch (Exception ex) {
            setDefaultCourseImage(imageView);
        }
    }

    private String normalizeUrl(String raw) {
        if (raw == null) return null;
        String candidate = raw.trim();
        if (candidate.isEmpty()) return null;
        candidate = candidate.replace('\\', '/');
        if (candidate.startsWith("//")) candidate = "https:" + candidate;

        if (!candidate.startsWith("http://") && !candidate.startsWith("https://")) {
            HttpUrl base = HttpUrl.parse(API_BASE);
            if (base == null) return null;
            HttpUrl resolved = base.resolve(candidate.startsWith("/") ? candidate : "/" + candidate);
            return resolved != null ? resolved.toString() : null;
        }
        HttpUrl url = HttpUrl.parse(candidate);
        if (url == null) return null;
        return url.newBuilder().build().toString();
    }

    private void setDefaultCourseImage(ImageView iv) {
        try {
            Image fallback = new Image(getClass().getResourceAsStream("/images/default-course.png"));
            if (fallback != null && !fallback.isError()) {
                iv.setImage(fallback);
                return;
            }
        } catch (Exception ignore) {}
        iv.setImage(null);
    }

    /* =============================== Reflection helpers =============================== */

    private String or(String... values) {
        for (String v : values) if (v != null && !v.isBlank()) return v;
        return null;
    }

    private Method findMethod(Object obj, String name) {
        if (obj == null || name == null) return null;
        try {
            return obj.getClass().getMethod(name);
        } catch (Exception e) {
            return null;
        }
    }

    private String getString(Object obj, String... methodNames) {
        for (String name : methodNames) {
            Method m = findMethod(obj, name);
            if (m != null) {
                try {
                    Object v = m.invoke(obj);
                    if (v != null) return String.valueOf(v);
                } catch (Exception ignore) {}
            }
        }
        return null;
    }

    private Boolean getBoolean(Object obj, String methodName) {
        Method m = findMethod(obj, methodName);
        if (m == null) return null;
        try {
            Object v = m.invoke(obj);
            return (v instanceof Boolean) ? (Boolean) v : null;
        } catch (Exception e) {
            return null;
        }
    }

    private Number getNumber(Object obj, String methodName) {
        Method m = findMethod(obj, methodName);
        if (m == null) return null;
        try {
            Object v = m.invoke(obj);
            return (v instanceof Number) ? (Number) v : null;
        } catch (Exception e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private List<String> getStringList(Object obj, String methodName) {
        Method m = findMethod(obj, methodName);
        if (m == null) return null;
        try {
            Object v = m.invoke(obj);
            if (v instanceof List<?>) {
                List<?> raw = (List<?>) v;
                List<String> out = new ArrayList<>(raw.size());
                for (Object o : raw) if (o != null) out.add(String.valueOf(o));
                return out;
            }
        } catch (Exception ignore) {}
        return null;
    }


}
