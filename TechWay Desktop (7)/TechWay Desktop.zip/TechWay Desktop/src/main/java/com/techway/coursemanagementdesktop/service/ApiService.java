package com.techway.coursemanagementdesktop.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

import com.techway.coursemanagementdesktop.AdminOverviewDTO;
import com.techway.coursemanagementdesktop.AdminUserDTO;
import com.techway.coursemanagementdesktop.EnrollmentDTO;
import com.techway.coursemanagementdesktop.dto.ApiResponse;
import com.techway.coursemanagementdesktop.dto.LoginRequest;
import com.techway.coursemanagementdesktop.dto.LoginResponse;
import com.techway.coursemanagementdesktop.dto.RegisterRequest;
import com.techway.coursemanagementdesktop.model.Course;
import com.techway.coursemanagementdesktop.model.Enrollment;
import com.techway.coursemanagementdesktop.model.LessonProgress;
import com.techway.coursemanagementdesktop.model.User;
import com.techway.coursemanagementdesktop.util.HttpRequestUtil;
import com.techway.coursemanagementdesktop.util.SessionManager;
import okhttp3.*;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import com.google.gson.reflect.TypeToken;


/**
 * API Service for communicating with Spring Boot backend
 */
public class ApiService {

    private static ApiService instance;
    private final OkHttpClient client;
    private final ObjectMapper objectMapper;
    private String baseUrl;

    private final HttpClient httpClient;


    // JSON MediaType
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    // ===== Base paths =====
    private static final String FAVORITES_BASE = "/api/favorites";
    private static final String ADMIN_BASE     = "/api/admin";
    private static final String ENROLLMENTS_BASE = "/api/enrollments";


    // Cookie storage (session-based auth support)
    private final Map<String, List<Cookie>> cookieStore = new ConcurrentHashMap<>();
    private volatile String xsrfToken;
    private final Gson gson = new Gson();

    public ApiService() {
        httpClient = HttpClient.newHttpClient();

        this.objectMapper = new ObjectMapper()
                .registerModule(new JavaTimeModule())
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

        this.client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .cookieJar(new CookieJar() {
                    @Override
                    public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
                        if (cookies == null || cookies.isEmpty()) return;
                        cookieStore.put(url.host(), cookies);
                        for (Cookie c : cookies) {
                            if ("XSRF-TOKEN".equalsIgnoreCase(c.name())) {
                                xsrfToken = c.value();
                            }
                        }
                    }
                    @Override
                    public List<Cookie> loadForRequest(HttpUrl url) {
                        return cookieStore.getOrDefault(url.host(), Collections.emptyList());
                    }
                })
                .addInterceptor(chain -> {
                    Request req = chain.request();
                    Request.Builder b = req.newBuilder();
                    if (xsrfToken != null && !"GET".equalsIgnoreCase(req.method())) {
                        b.header("X-XSRF-TOKEN", xsrfToken);
                    }
                    return chain.proceed(b.build());
                })
                .build();
    }

    public static List<LessonProgress> parseLessonProgressList(String json) {
        Gson gson = new Gson();
        Type listType = new TypeToken<List<LessonProgress>>() {}.getType();
        return gson.fromJson(json, listType);
    }

    public static void initialize(String baseUrl) {
        if (instance == null) {
            instance = new ApiService();
        }
        instance.baseUrl = baseUrl;
    }

    public static ApiService getInstance() {
        if (instance == null) throw new IllegalStateException("ApiService not initialized. Call initialize() first.");
        return instance;
    }

    // ========================= AUTH =========================

    public CompletableFuture<LoginResponse> login(String email, String password) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                LoginRequest loginRequest = new LoginRequest(email, password);
                String json = objectMapper.writeValueAsString(loginRequest);

                RequestBody body = RequestBody.create(json, JSON);
                Request request = new Request.Builder()
                        .url(baseUrl + "/api/auth/login")
                        .post(body)
                        .header("Content-Type", "application/json")
                        .header("Accept", "application/json")
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    String responseBody = response.body() != null ? response.body().string() : "";

                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Login failed: HTTP " + response.code() + " - " + responseBody);
                    }

                    LoginResponse out = null;
                    try {
                        ApiResponse<LoginResponse> apiResponse = objectMapper.readValue(
                                responseBody,
                                objectMapper.getTypeFactory().constructParametricType(ApiResponse.class, LoginResponse.class)
                        );
                        out = apiResponse.getData();
                    } catch (Exception ignore) { }

                    if (out == null) {
                        JsonNode root = objectMapper.readTree(responseBody);
                        JsonNode dataNode = root.path("data");
                        out = new LoginResponse();
                        if (dataNode.isObject()) {
                            if (dataNode.has("user")) {
                                out.setUser(objectMapper.treeToValue(dataNode.get("user"), User.class));
                            } else if (dataNode.has("id") || dataNode.has("email")) {
                                out.setUser(objectMapper.treeToValue(dataNode, User.class));
                            }
                            if (dataNode.has("token") && !dataNode.get("token").isNull())
                                out.setToken(dataNode.get("token").asText());
                            else if (dataNode.has("accessToken"))
                                out.setToken(dataNode.get("accessToken").asText());
                            else if (dataNode.has("jwt"))
                                out.setToken(dataNode.get("jwt").asText());
                        }
                    }

                    if (out != null && (out.getToken() == null || out.getToken().isBlank())) {
                        String authHeader = response.header("Authorization");
                        if (authHeader != null && authHeader.toLowerCase().startsWith("bearer ")) {
                            out.setToken(authHeader.substring(7).trim());
                        }
                    }

                    if (out == null || out.getUser() == null) {
                        throw new RuntimeException("Login error: user missing in response");
                    }

                    return out;
                }
            } catch (IOException e) {
                throw new RuntimeException("Login error: network/IO - " + e.getMessage(), e);
            } catch (Exception e) {
                throw new RuntimeException("Login error: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<User> register(String name, String email, String password) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                RegisterRequest registerRequest = new RegisterRequest(name, email, password);
                String json = objectMapper.writeValueAsString(registerRequest);

                RequestBody body = RequestBody.create(json, JSON);
                Request request = new Request.Builder()
                        .url(baseUrl + "/api/auth/register")
                        .post(body)
                        .header("Content-Type", "application/json")
                        .header("Accept", "application/json")
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    String responseBody = response.body() != null ? response.body().string() : "";

                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Registration failed: HTTP " + response.code() + " - " + responseBody);
                    }

                    ApiResponse<User> apiResponse = objectMapper.readValue(
                            responseBody,
                            objectMapper.getTypeFactory().constructParametricType(ApiResponse.class, User.class)
                    );
                    return apiResponse.getData();
                }
            } catch (Exception e) {
                throw new RuntimeException("Registration error: " + e.getMessage(), e);
            }
        });
    }

    // ========================= COURSES =========================

    public CompletableFuture<List<Course>> getAllCourses() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Request request = new Request.Builder()
                        .url(baseUrl + "/api/courses")
                        .get()
                        .header("Accept", "application/json")
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    String responseBody = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Failed to fetch courses: HTTP " + response.code() + " - " + responseBody);
                    }
                    ApiResponse<List<Course>> apiResponse = objectMapper.readValue(
                            responseBody,
                            objectMapper.getTypeFactory().constructParametricType(
                                    ApiResponse.class,
                                    objectMapper.getTypeFactory().constructCollectionType(List.class, Course.class)
                            )
                    );
                    return apiResponse.getData();
                }
            } catch (Exception e) {
                throw new RuntimeException("Error fetching courses: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Course> getCourseById(Long courseId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Request request = new Request.Builder()
                        .url(baseUrl + "/api/courses/" + courseId)
                        .get()
                        .header("Accept", "application/json")
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    String responseBody = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Failed to fetch course: HTTP " + response.code() + " - " + responseBody);
                    }
                    ApiResponse<Course> apiResponse = objectMapper.readValue(
                            responseBody,
                            objectMapper.getTypeFactory().constructParametricType(ApiResponse.class, Course.class)
                    );
                    return apiResponse.getData();
                }
            } catch (Exception e) {
                throw new RuntimeException("Error fetching course: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<List<Course>> searchCourses(String keyword, String location, Boolean isFree) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpUrl.Builder urlBuilder = HttpUrl.parse(baseUrl + "/api/courses/search").newBuilder();
                if (keyword != null && !keyword.trim().isEmpty()) urlBuilder.addQueryParameter("keyword", keyword.trim());
                if (location != null && !location.trim().isEmpty()) urlBuilder.addQueryParameter("location", location.trim());
                if (isFree != null) urlBuilder.addQueryParameter("isFree", isFree.toString());

                Request request = new Request.Builder()
                        .url(urlBuilder.build())
                        .get()
                        .header("Accept", "application/json")
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    String responseBody = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Search failed: HTTP " + response.code() + " - " + responseBody);
                    }
                    ApiResponse<List<Course>> apiResponse = objectMapper.readValue(
                            responseBody,
                            objectMapper.getTypeFactory().constructParametricType(
                                    ApiResponse.class,
                                    objectMapper.getTypeFactory().constructCollectionType(List.class, Course.class)
                            )
                    );
                    return apiResponse.getData();
                }
            } catch (Exception e) {
                throw new RuntimeException("Search error: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<List<Course>> getFreeCourses() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Request request = new Request.Builder()
                        .url(baseUrl + "/api/courses/free")
                        .get()
                        .header("Accept", "application/json")
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    String responseBody = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Failed to fetch free courses: HTTP " + response.code() + " - " + responseBody);
                    }
                    ApiResponse<List<Course>> apiResponse = objectMapper.readValue(
                            responseBody,
                            objectMapper.getTypeFactory().constructParametricType(
                                    ApiResponse.class,
                                    objectMapper.getTypeFactory().constructCollectionType(List.class, Course.class)
                            )
                    );
                    return apiResponse.getData();
                }
            } catch (Exception e) {
                throw new RuntimeException("Error fetching free courses: " + e.getMessage(), e);
            }
        });
    }

    // ========================= FAVORITES (Wishlist) =========================

    private <T> T extractDataOrWhole(String body, TypeReference<T> typeRef) throws IOException {
        JsonNode root;
        try { root = objectMapper.readTree(body); }
        catch (Exception e) { return objectMapper.readValue(body, typeRef); }
        JsonNode data = root.get("data");
        if (data != null && !data.isNull()) return objectMapper.convertValue(data, typeRef);
        return objectMapper.readValue(body, typeRef);
    }

    private Request.Builder withAuth(Request.Builder builder) {
        String token = null;
        try { token = SessionManager.getInstance().getAuthToken(); } catch (Exception ignore) {
            System.err.println("ERRORRRRRRRRRRRR");
            ignore.printStackTrace();}
        if (token != null && !token.isEmpty()) {
            builder.header("Authorization", "Bearer " + token);
        }
        builder.header("Accept", "application/json");
        if (xsrfToken != null) builder.header("X-XSRF-TOKEN", xsrfToken);
        return builder;
    }

    public CompletableFuture<List<Long>> getFavoriteIds() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Long userId = SessionManager.getInstance().getCurrentUserId();
                if (userId == null) return new ArrayList<>();

                Request request = withAuth(new Request.Builder()
                        .url(baseUrl + FAVORITES_BASE + "/user/" + userId)
                        .get()).build();

                try (Response response = client.newCall(request).execute()) {
                    String body = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Failed to fetch favorite ids: HTTP " + response.code() + " - " + body);
                    }
                    List<Course> courses = extractDataOrWhole(body, new TypeReference<List<Course>>() {});
                    List<Long> ids = new ArrayList<>();
                    for (Course c : courses) {
                        if (c != null && c.getId() != null) ids.add(c.getId());
                    }
                    return ids;
                }
            } catch (Exception e) {
                throw new RuntimeException("Error fetching favorite ids: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<List<Course>> getFavorites() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Long userId = SessionManager.getInstance().getCurrentUserId();
                if (userId == null) return new ArrayList<>();

                Request request = withAuth(new Request.Builder()
                        .url(baseUrl + FAVORITES_BASE + "/user/" + userId)
                        .get()).build();

                try (Response response = client.newCall(request).execute()) {
                    String body = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Failed to fetch favorites: HTTP " + response.code() + " - " + body);
                    }
                    return extractDataOrWhole(body, new TypeReference<List<Course>>() {});
                }
            } catch (Exception e) {
                throw new RuntimeException("Error fetching favorites: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Boolean> isFavorite(Long courseId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Long userId = SessionManager.getInstance().getCurrentUserId();
                if (userId == null || courseId == null) return false;

                Request request = withAuth(new Request.Builder()
                        .url(baseUrl + FAVORITES_BASE + "/user/" + userId + "/course/" + courseId + "/check")
                        .get()).build();

                try (Response response = client.newCall(request).execute()) {
                    String body = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        if (response.code() == 404) return false;
                        throw new RuntimeException("Failed to check favorite: HTTP " + response.code() + " - " + body);
                    }
                    try {
                        JsonNode root = objectMapper.readTree(body);
                        if (root.has("data")) {
                            JsonNode d = root.get("data");
                            if (d.isBoolean()) return d.asBoolean();
                        }
                        if (root.has("success") && root.get("success").asBoolean()) {
                            return true;
                        }
                        return objectMapper.readValue(body, Boolean.class);
                    } catch (Exception ignore) {
                        return false;
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException("Error checking favorite: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<List<Course>> getFavoritesByUserId(Long userId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Request request = new Request.Builder()
                        .url(baseUrl + "/api/favorites/user/" + userId) // تأكد من مسار الـ API عندك
                        .get()
                        .header("Accept", "application/json")
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    String responseBody = response.body() != null ? response.body().string() : "";

                    if (response.isSuccessful()) {
                        ApiResponse<List<Course>> apiResponse = objectMapper.readValue(
                                responseBody,
                                objectMapper.getTypeFactory().constructParametricType(
                                        ApiResponse.class,
                                        objectMapper.getTypeFactory().constructCollectionType(List.class, Course.class)
                                )
                        );
                        return apiResponse.getData();
                    } else {
                        throw new RuntimeException("Failed to fetch favorites: HTTP "
                                + response.code() + " - " + responseBody);
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException("Error fetching favorites: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Boolean> addFavorite(Long courseId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Long userId = SessionManager.getInstance().getCurrentUserId();
                if (userId == null || courseId == null) return false;

                Map<String, Object> requestBody = new HashMap<>();
                requestBody.put("userId", userId);
                requestBody.put("courseId", courseId);

                Request request = withAuth(new Request.Builder()
                        .url(baseUrl + FAVORITES_BASE))
                        .post(RequestBody.create(objectMapper.writeValueAsString(requestBody), JSON))
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    String body = response.body() != null ? response.body().string() : "";
                    if (response.isSuccessful()) return true;
                    throw new RuntimeException("Add favorite failed: HTTP " + response.code() + " - " + body);
                }
            } catch (Exception e) {
                throw new RuntimeException("Error adding favorite: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Boolean> removeFavorite(Long courseId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Long userId = SessionManager.getInstance().getCurrentUserId();
                if (userId == null || courseId == null) return false;

                Request request = withAuth(new Request.Builder()
                        .url(baseUrl + FAVORITES_BASE + "/user/" + userId + "/course/" + courseId))
                        .delete()
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    String body = response.body() != null ? response.body().string() : "";
                    if (response.isSuccessful()) return true;
                    if (response.code() == 404) return true;
                    throw new RuntimeException("Remove favorite failed: HTTP " + response.code() + " - " + body);
                }
            } catch (Exception e) {
                throw new RuntimeException("Error removing favorite: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Boolean> toggleFavorite(Long courseId) {
        return isFavorite(courseId).thenCompose(current -> {
            if (Boolean.TRUE.equals(current)) {
                return removeFavorite(courseId).thenApply(ok -> ok ? false : true);
            } else {
                return addFavorite(courseId).thenApply(ok -> ok ? true : false);
            }
        });
    }

    // ========================= ADMIN =========================

    public CompletableFuture<List<Course>> adminListCourses(String q) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String url = baseUrl + ADMIN_BASE + "/courses";
                if (q != null && !q.isBlank()) {
                    url += "?q=" + URLEncoder.encode(q.trim(), StandardCharsets.UTF_8);
                }
                Request request = withAuth(new Request.Builder().url(url).get()).build();

                try (Response response = client.newCall(request).execute()) {
                    String body = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Admin list courses failed: HTTP " + response.code() + ", error: " + body);
                    }
                    return extractDataOrWhole(body, new TypeReference<List<Course>>() {});
                }
            } catch (Exception e) {
                throw new RuntimeException("Admin list courses error: " + e.getMessage(), e);
            }
        });
    }

    public static class CourseAdminRequest {
        public String title, description, location, instructor, status, imageUrl;
        public Double price;
        public Integer duration;
        public Boolean isFree;
    }

    public CompletableFuture<Boolean> adminCreateCourse(Object form) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                CourseAdminRequest reqObj = toCourseAdminRequest(form);
                // إضافة isFree بناء على السعر
                if (reqObj.isFree == null) {
                    reqObj.isFree = reqObj.price == null || reqObj.price <= 0.0;
                }

                Request req = withAuth(new Request.Builder()
                        .url(baseUrl + ADMIN_BASE + "/courses"))
                        .post(RequestBody.create(objectMapper.writeValueAsBytes(reqObj), JSON))
                        .build();
                try (Response res = client.newCall(req).execute()) {
                    String body = res.body() != null ? res.body().string() : "";
                    if (!res.isSuccessful()) throw new RuntimeException("Create course failed: HTTP " + res.code() + " - " + body);
                    return true;
                }
            } catch (Exception e) {
                throw new RuntimeException("Admin create course error: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Boolean> adminUpdateCourse(long id, Object form) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                CourseAdminRequest reqObj = toCourseAdminRequest(form);
                // إضافة isFree بناء على السعر
                if (reqObj.isFree == null) {
                    reqObj.isFree = reqObj.price == null || reqObj.price <= 0.0;
                }

                Request req = withAuth(new Request.Builder()
                        .url(baseUrl + ADMIN_BASE + "/courses/" + id))
                        .put(RequestBody.create(objectMapper.writeValueAsBytes(reqObj), JSON))
                        .build();
                try (Response res = client.newCall(req).execute()) {
                    String body = res.body() != null ? res.body().string() : "";
                    if (!res.isSuccessful()) throw new RuntimeException("Update course failed: HTTP " + res.code() + " - " + body);
                    return true;
                }
            } catch (Exception e) {
                throw new RuntimeException("Admin update course error: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Boolean> adminDeleteCourse(long id) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Request req = withAuth(new Request.Builder()
                        .url(baseUrl + ADMIN_BASE + "/courses/" + id))
                        .delete()
                        .build();
                try (Response res = client.newCall(req).execute()) {
                    String body = res.body() != null ? res.body().string() : "";
                    if (!res.isSuccessful()) throw new RuntimeException("Delete course failed: HTTP " + res.code() + " - " + body);
                    return true;
                }
            } catch (Exception e) {
                throw new RuntimeException("Admin delete course error: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<List<User>> adminListUsers(String q) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String url = baseUrl + ADMIN_BASE + "/users";
                if (q != null && !q.isBlank()) url += "?q=" + URLEncoder.encode(q.trim(), StandardCharsets.UTF_8);
                Request request = withAuth(new Request.Builder().url(url).get()).build();

                try (Response response = client.newCall(request).execute()) {
                    String body = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Admin list users failed: HTTP " + response.code() + ", error: " + body);
                    }
                    return extractDataOrWhole(body, new TypeReference<List<User>>() {});
                }
            } catch (Exception e) {
                throw new RuntimeException("Admin list users error: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Boolean> adminSetRole(long userId, String role) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Map<String, String> requestBody = new HashMap<>();
                requestBody.put("role", role);

                Request req = withAuth(new Request.Builder()
                        .url(baseUrl + ADMIN_BASE + "/users/" + userId + "/role"))
                        .put(RequestBody.create(objectMapper.writeValueAsString(requestBody), JSON))
                        .build();
                try (Response res = client.newCall(req).execute()) {
                    String body = res.body() != null ? res.body().string() : "";
                    if (!res.isSuccessful()) throw new RuntimeException("Set role failed: HTTP " + res.code() + " - " + body);
                    return true;
                }
            } catch (Exception e) {
                throw new RuntimeException("Admin set role error: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Boolean> adminDisableUser(long userId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                // نظراً لعدم وجود endpoint للتعطيل في الباك إند، نعطي false مباشرة
                return false;
            } catch (Exception e) {
                throw new RuntimeException("Admin disable user error: " + e.getMessage(), e);
            }
        });
    }

    public CompletableFuture<Boolean> adminDeleteUser(long userId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Request req = withAuth(new Request.Builder()
                        .url(baseUrl + ADMIN_BASE + "/users/" + userId))
                        .delete()
                        .build();
                try (Response res = client.newCall(req).execute()) {
                    String body = res.body() != null ? res.body().string() : "";
                    if (!res.isSuccessful()) throw new RuntimeException("Delete user failed: HTTP " + res.code() + " - " + body);
                    return true;
                }
            } catch (Exception e) {
                throw new RuntimeException("Admin delete user error: " + e.getMessage(), e);
            }
        });
    }



    public AdminOverviewDTO fetchDashboardStats() {
        try {
            // إعداد الطلب
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(baseUrl+ADMIN_BASE + "/dashboard"))
                    .header("Accept", "application/json")
                    .build();

            // إرسال الطلب واستلام الاستجابة
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            // التحقق من نجاح الطلب
            if (response.statusCode() == 200) {
                // تحويل JSON إلى كائن Java
                String responseBody = response.body();
                Type type = new TypeToken<ApiResponse<AdminOverviewDTO>>() {}.getType();
                ApiResponse<AdminOverviewDTO> apiResponse = gson.fromJson(responseBody, type);
                return apiResponse.getData();
            } else {
                System.err.println("فشل في جلب البيانات: " + response.statusCode());
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }

        return null;
    }

    public List<AdminUserDTO> fetchAllUsers() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(ADMIN_BASE + "/users"))
                    .header("Accept", "application/json")
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                String responseBody = response.body();
                Type type = new TypeToken<ApiResponse<List<AdminUserDTO>>>() {}.getType();
                ApiResponse<List<AdminUserDTO>> apiResponse = gson.fromJson(responseBody, type);
                return apiResponse.getData();
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }





    // ========================= UTIL =========================

    private CourseAdminRequest toCourseAdminRequest(Object form) {
        return objectMapper.convertValue(form, CourseAdminRequest.class);
    }

    public static class ApiException extends RuntimeException {
        public ApiException(String message) { super(message); }
        public ApiException(String message, Throwable cause) { super(message, cause); }
    }

    // تسجيل المستخدم في كورس
    public CompletableFuture<Enrollment> enrollUser(Long userId, Long courseId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Map<String, Long> payload = new HashMap<>();
                payload.put("userId", userId);
                payload.put("courseId", courseId);

                Request request = withAuth(new Request.Builder()
                        .url(baseUrl + ENROLLMENTS_BASE)
                        .post(RequestBody.create(objectMapper.writeValueAsString(payload), JSON))
                ).build();

                try (Response response = client.newCall(request).execute()) {
                    String body = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Enrollment failed: HTTP " + response.code() + " - " + body);
                    }

                    // استقبل DTO من الـ backend
                    return objectMapper.readValue(body, Enrollment.class);
                }
            } catch (Exception e) {
                throw new RuntimeException("Error enrolling user: " + e.getMessage(), e);
            }
        });
    }

    // تسجيل المستخدم في كورس
    public CompletableFuture<EnrollmentDTO> enrollUser2(Long userId, Long courseId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Map<String, Long> payload = new HashMap<>();
                payload.put("userId", userId);
                payload.put("courseId", courseId);

                Request request = withAuth(new Request.Builder()
                        .url(baseUrl + ENROLLMENTS_BASE)
                        .post(RequestBody.create(objectMapper.writeValueAsString(payload), JSON))
                ).build();

                try (Response response = client.newCall(request).execute()) {
                    String body = response.body() != null ? response.body().string() : "";
                    if (!response.isSuccessful()) {
                        throw new RuntimeException("Enrollment failed: HTTP " + response.code() + " - " + body);
                    }

                    // استقبل DTO من الـ backend
                    return objectMapper.readValue(body, EnrollmentDTO.class);
                }
            } catch (Exception e) {
                throw new RuntimeException("Error enrolling user: " + e.getMessage(), e);
            }
        });
    }


    // ========================= ENROLLMENTS =========================


    public CompletableFuture<List<EnrollmentDTO>> getUserEnrollments(Long userId) {
        String url = baseUrl + "/api/enrollments/user/" + userId;

        return HttpRequestUtil.sendGetRequest(url)
                .thenApply(response -> {
                    try {
                        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
                        JsonArray dataArray = json.getAsJsonArray("data");

                        Type listType = new TypeToken<List<EnrollmentDTO>>() {}.getType();
                        return new Gson().fromJson(dataArray, listType);

                    } catch (Exception e) {
                        e.printStackTrace();
                        throw new RuntimeException("فشل في معالجة استجابة التسجيلات", e);
                    }
                });
    }








    public CompletableFuture<Boolean> deleteEnrollment(Long enrollmentId) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Request request = new Request.Builder()
                        .url(baseUrl + "/api/enrollments/" + enrollmentId)
                        .delete()
                        .build();

                try (Response response = client.newCall(request).execute()) {
                    return response.isSuccessful();
                }
            } catch (Exception e) {
                throw new RuntimeException("Error deleting enrollment: " + e.getMessage(), e);
            }
        });
    }


    // ✅ أضف هذه الدالة 👇
    public CompletableFuture<List<Map<String, Object>>> getLessonsForCourse(Long courseId) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("http://localhost:8080/api/courses/" + courseId + "/lessons"))
                .GET()
                .build();

        return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .thenApply(body -> {
                    try {
                        return objectMapper.readValue(body, new TypeReference<List<Map<String, Object>>>() {});
                    } catch (Exception e) {
                        e.printStackTrace();
                        return List.of();
                    }
                });
    }


    public void markLessonAsCompleted(Long enrollmentId, Long lessonId) {
        String url = baseUrl + "/api/lesson-progress/complete";

        Map<String, Long> payload = new HashMap<>();
        payload.put("enrollmentId", enrollmentId);
        payload.put("lessonId", lessonId);

        String json = new Gson().toJson(payload);

        HttpRequestUtil.sendPostRequest(url, json)
                .thenAccept(response -> {
                    System.out.println("✅ تم تسجيل مشاهدة الدرس");
                    // هنا ممكن تحدث واجهة المستخدم لو تحب
                })
                .exceptionally(ex -> {
                    ex.printStackTrace();
                    return null;
                });
    }

    public void fetchLessonProgressByEnrollment(Long enrollmentId, Consumer<List<LessonProgress>> onSuccess, Consumer<Throwable> onError) {
        String url = baseUrl + "/api/lesson-progress/by-enrollment/" + enrollmentId;

        HttpRequestUtil.sendGetRequest("http://localhost:8080/api/lesson-progress/by-enrollment/14")
                .thenAccept(json -> {
                    List<LessonProgress> progresses = ApiService.parseLessonProgressList(json);
                    progresses.forEach(p -> System.out.println("Lesson ID: " + p.getId() + ", Completed: " + p.isCompleted()));

                    // هنا تقدر تحدث الواجهة، مثلاً:
                    // tableView.setItems(FXCollections.observableArrayList(progresses));
                })
                .exceptionally(ex -> {
                    ex.printStackTrace();
                    return null;
                });
    }

    public double calculateProgressPercentage(List<LessonProgress> progressList) {
        if (progressList == null || progressList.isEmpty()) return 0.0;

        long completedCount = progressList.stream()
                .filter(LessonProgress::isCompleted)
                .count();

        return (completedCount * 100.0) / progressList.size();
    }


    public CompletableFuture<List<LessonProgress>> getLessonProgressByEnrollmentId(Long enrollmentId) {
        String url = baseUrl + "/api/lesson-progress/by-enrollment/" + enrollmentId;

        return HttpRequestUtil.sendGetRequest(url)
                .thenApply(responseBody -> {
                    // هنا بتحول JSON لليست من LessonProgress (تحتاج تعريف LessonProgress في الواجهة)
                    Type listType = new TypeToken<List<LessonProgress>>() {}.getType();
                    return new Gson().fromJson(responseBody, listType);
                });
    }



}


