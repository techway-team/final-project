package com.techway.coursemanagementdesktop.controller;

import javafx.geometry.Insets;
import javafx.geometry.NodeOrientation;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.shape.Rectangle;

public class ContactPageController {

    private static final double CONTENT_WIDTH = 1100;
    private final MainController mainController;

    public ContactPageController(MainController mainController) {
        this.mainController = mainController;
    }

    public VBox createContactPage() {
        VBox root = new VBox(28);
        root.setPadding(new Insets(36));
        root.setAlignment(Pos.TOP_CENTER);
        root.setNodeOrientation(NodeOrientation.RIGHT_TO_LEFT);

        // CSS مخصص للاتصال
        try {
            root.getStylesheets().add(
                    getClass().getResource("/css/contact-styles.css").toExternalForm()
            );
        } catch (Exception ignore) {}

        VBox container = new VBox(24);
        container.setMaxWidth(CONTENT_WIDTH);

        // Hero
        VBox hero = new VBox(10);
        hero.setAlignment(Pos.CENTER);
        Label title = new Label("اتصل بنا");
        title.getStyleClass().add("contact-hero-title");
        Label subtitle = new Label("نحن هنا لمساعدتك. تواصل معنا في أي وقت وسنرد عليك في أقرب وقت ممكن.");
        subtitle.getStyleClass().add("contact-hero-subtitle");
        subtitle.setWrapText(true);
        subtitle.setMaxWidth(CONTENT_WIDTH - 240);
        hero.getChildren().addAll(title, subtitle);

        // Grid: يسار (النموذج) — يمين (معلومات التواصل + FAQ)
        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(20);

        ColumnConstraints c1 = new ColumnConstraints();
        c1.setPercentWidth(60); // النموذج
        ColumnConstraints c2 = new ColumnConstraints();
        c2.setPercentWidth(40); // المعلومات
        grid.getColumnConstraints().addAll(c1, c2);

        // ===== Left: Form Card =====
        VBox formCard = new VBox(16);
        formCard.getStyleClass().add("contact-card");
        formCard.setPadding(new Insets(22));

        Label formTitle = new Label("أرسل لنا رسالة");
        formTitle.getStyleClass().add("section-title");

        GridPane formGrid = new GridPane();
        formGrid.setHgap(14);
        formGrid.setVgap(14);
        ColumnConstraints f1 = new ColumnConstraints(); f1.setPercentWidth(50);
        ColumnConstraints f2 = new ColumnConstraints(); f2.setPercentWidth(50);
        formGrid.getColumnConstraints().addAll(f1, f2);

        // Fields
        TextField emailField = new TextField();
        emailField.setPromptText("your@email.com");
        emailField.getStyleClass().add("input");
        addLabeledField(formGrid, "البريد الإلكتروني *", emailField, 0, 0);

        TextField nameField = new TextField();
        nameField.setPromptText("اسمك الكامل");
        nameField.getStyleClass().add("input");
        addLabeledField(formGrid, "الاسم *", nameField, 1, 0);

        TextField subjectField = new TextField();
        subjectField.setPromptText("موضوع رسالتك");
        subjectField.getStyleClass().add("input");
        addLabeledField(formGrid, "الموضوع *", subjectField, 0, 1, 2);

        TextArea messageArea = new TextArea();
        messageArea.setPromptText("اكتب رسالتك هنا...");
        messageArea.setPrefRowCount(6);
        messageArea.getStyleClass().add("textarea");
        addLabeledArea(formGrid, "الرسالة *", messageArea, 0, 2, 2);

        Button sendBtn = new Button("إرسال الرسالة ✈️");
        sendBtn.getStyleClass().addAll("primary-button", "btn-full");
        sendBtn.setOnAction(e -> {
            if (emailField.getText().trim().isEmpty()
                    || nameField.getText().trim().isEmpty()
                    || subjectField.getText().trim().isEmpty()
                    || messageArea.getText().trim().isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "يرجى تعبئة جميع الحقول المطلوبة.");
                return;
            }
            showAlert(Alert.AlertType.INFORMATION, "تم إرسال رسالتك بنجاح. سنعاود الاتصال بك قريبًا.");
            emailField.clear(); nameField.clear(); subjectField.clear(); messageArea.clear();
        });

        formCard.getChildren().addAll(formTitle, formGrid, sendBtn);

        // قص بسيط للكارت
        Rectangle clip = new Rectangle();
        clip.setArcWidth(12); clip.setArcHeight(12);
        formCard.setClip(clip);
        formCard.layoutBoundsProperty().addListener((obs, o, n) -> {
            clip.setWidth(n.getWidth()); clip.setHeight(n.getHeight());
        });

        // ===== Right: Info + FAQ =====
        VBox rightCol = new VBox(16);

        VBox infoCard = new VBox(16);
        infoCard.getStyleClass().add("contact-card");
        infoCard.setPadding(new Insets(22));

        Label infoTitle = new Label("معلومات التواصل");
        infoTitle.getStyleClass().add("section-title");

        // Email
        infoCard.getChildren().add(buildInfoItem("📧", "البريد الإلكتروني",
                "info@TechWay.com\nsupport@TechWay.com"));

        // Phone
        infoCard.getChildren().add(buildInfoItem("📞", "الهاتف",
                "4567 123 50 966+\n7890 456 11 966+"));

        // Address
        infoCard.getChildren().add(buildInfoItem("📍", "العنوان",
                "الرياض، حي الملك فهد\nالمملكة العربية السعودية"));

        // Hours
        infoCard.getChildren().add(buildInfoItem("⏰", "ساعات العمل",
                "الأحد - الخميس: 18:00 - 9:00\nالجمعة - السبت: مغلق"));

        // FAQ
        VBox faqCard = new VBox(14);
        faqCard.getStyleClass().add("contact-card");
        faqCard.setPadding(new Insets(22));

        Label faqTitle = new Label("أسئلة شائعة");
        faqTitle.getStyleClass().add("section-title");

        faqCard.getChildren().addAll(
                buildFaqItem("كم يستغرق الرد على الاستفسارات؟",
                        "نرد خلال 24 ساعة في أيام العمل."),
                buildFaqItem("هل يمكنكم مساعدتي في اختيار كورسات مناسبة؟",
                        "أكيد. اذكر لنا مستواك واهتمامك ونقترح لك المسار المناسب.")
        );

        rightCol.getChildren().addAll(infoCard, faqCard);

        // ضع العناصر في الشبكة
        grid.add(formCard, 0, 0);
        grid.add(rightCol, 1, 0);

        container.getChildren().addAll(hero, grid);
        root.getChildren().add(container);
        return root;
    }

    /* ===== helpers ===== */

    private void addLabeledField(GridPane grid, String label, TextField field, int col, int row) {
        addLabeledField(grid, label, field, col, row, 1);
    }

    private void addLabeledField(GridPane grid, String label, TextField field, int col, int row, int colspan) {
        VBox box = new VBox(6);
        Label l = new Label(label);
        l.getStyleClass().add("form-label");
        box.getChildren().addAll(l, field);
        GridPane.setColumnIndex(box, col);
        GridPane.setRowIndex(box, row);
        GridPane.setColumnSpan(box, colspan);
        grid.getChildren().add(box);
    }

    private void addLabeledArea(GridPane grid, String label, TextArea area, int col, int row, int colspan) {
        VBox box = new VBox(6);
        Label l = new Label(label);
        l.getStyleClass().add("form-label");
        box.getChildren().addAll(l, area);
        GridPane.setColumnIndex(box, col);
        GridPane.setRowIndex(box, row);
        GridPane.setColumnSpan(box, colspan);
        grid.getChildren().add(box);
    }

    private HBox buildInfoItem(String emoji, String title, String text) {
        HBox row = new HBox(12);
        row.setAlignment(Pos.TOP_RIGHT);

        Label icon = new Label(emoji);
        icon.getStyleClass().add("icon-badge");

        VBox texts = new VBox(4);
        Label t = new Label(title);
        t.getStyleClass().add("info-title");
        Label d = new Label(text);
        d.getStyleClass().add("info-text");
        d.setWrapText(true);

        texts.getChildren().addAll(t, d);
        row.getChildren().addAll(texts, icon);
        return row;
    }

    private VBox buildFaqItem(String q, String a) {
        VBox box = new VBox(4);
        Label ql = new Label(q);
        ql.getStyleClass().add("faq-q");
        Label al = new Label(a);
        al.getStyleClass().add("faq-a");
        al.setWrapText(true);
        box.getChildren().addAll(ql, al);
        return box;
    }

    private void showAlert(Alert.AlertType type, String msg) {
        Alert alert = new Alert(type);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.setTitle("اتصل بنا");
        alert.showAndWait();
    }
}
