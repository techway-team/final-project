package com.techway.coursemanagementdesktop.controller.admin;


import com.techway.coursemanagementdesktop.AdminOverviewDTO;
import com.techway.coursemanagementdesktop.AdminUserDTO;
import com.techway.coursemanagementdesktop.TechWayApplication;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import com.techway.coursemanagementdesktop.service.ApiService;

import java.util.List;

public class AdminDashboardController {

    @FXML private Label totalCoursesLabel;
    @FXML private Label freeCoursesLabel;
    @FXML private Label paidCoursesLabel;

    @FXML private Label totalUsersLabel;
    @FXML private Label newUsers30dLabel;
    @FXML private Label activeUsersLabel;

    @FXML private TableView<AdminUserDTO> recentUsersTable;
    @FXML private TableColumn<AdminUserDTO, String> usernameColumn;
    @FXML private TableColumn<AdminUserDTO, String> emailColumn;
    @FXML private TableColumn<AdminUserDTO, String> registrationDateColumn;

    private final ApiService apiService = new ApiService();

    @FXML
    public void initialize() {
        loadDashboardData();
        loadRecentUsers();
        Scene scene = TechWayApplication.getPrimaryStage().getScene();

        scene.getStylesheets().add(
                getClass().getResource("/fxml/admin/css/style.css").toExternalForm()
        );
    }

    private void loadDashboardData() {
        AdminOverviewDTO dto = apiService.fetchDashboardStats();
        if (dto != null) {
            totalCoursesLabel.setText(String.valueOf(dto.getTotalCourses()));
            freeCoursesLabel.setText(String.valueOf(dto.getFreeCourses()));
            paidCoursesLabel.setText(String.valueOf(dto.getPaidCourses()));
            totalUsersLabel.setText(String.valueOf(dto.getTotalUsers()));
            newUsers30dLabel.setText(String.valueOf(dto.getNewUsersThisMonth()));
            activeUsersLabel.setText(String.valueOf(dto.getTotalEnrollments()));
        }
    }

    private void loadRecentUsers() {
        List<AdminUserDTO> users = apiService.fetchAllUsers();
        if (users != null) {
            usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
            emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
            registrationDateColumn.setCellValueFactory(new PropertyValueFactory<>("createdAt"));

            recentUsersTable.getItems().setAll(users);
        }
    }

    @FXML
    private void onBack() {
        // اكشن الرجوع
        System.out.println("رجوع");
    }
}
