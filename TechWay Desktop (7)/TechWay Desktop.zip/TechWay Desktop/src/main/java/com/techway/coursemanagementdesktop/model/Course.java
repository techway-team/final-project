package com.techway.coursemanagementdesktop.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Course Model - matches backend Course entity
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Course {

    private Long id;
    private String title;
    private String description;
    private String location;

    // من الباك احتمال يجي رقم ساعات
    private Integer duration;

    private BigDecimal price;

    @JsonProperty("isFree")
    @JsonAlias({"is_free", "free", "freeCourse"})
    private Boolean isFree;

    private String instructor;

    // حالة الكورس (مطلوبة للأدمن: Published/Draft/Inactive ... الخ)
    private String status;

    // نقبل كل الصيغ الشائعة للصورة
    @JsonProperty("imageUrl")
    @JsonAlias({"image_url", "image-url", "image"})
    private String imageUrl;

    @JsonProperty("createdAt")
    @JsonAlias({"created_at"})
    private LocalDateTime createdAt;

    public Course() {
        this.isFree = false;
        this.price = BigDecimal.ZERO;
    }

    // ===== Getters / Setters =====
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title != null ? title : ""; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description != null ? description : ""; }
    public void setDescription(String description) { this.description = description; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public Integer getDuration() { return duration; }
    public void setDuration(Integer duration) { this.duration = duration; }

    public BigDecimal getPrice() { return price != null ? price : BigDecimal.ZERO; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public Boolean getIsFree() { return isFree != null ? isFree : Boolean.FALSE; }
    public void setIsFree(Boolean isFree) { this.isFree = isFree; }

    public String getInstructor() { return instructor; }
    public void setInstructor(String instructor) { this.instructor = instructor; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    // ===== مساعدات عرض =====
    public String getPriceDisplay() {
        if (Boolean.TRUE.equals(getIsFree())) return "مجاني";
        return getPrice().stripTrailingZeros().toPlainString() + " ريال";
    }

    public String getDurationDisplay() {
        if (duration == null) return "غير محدد";
        return duration + " ساعة";
    }

    public String getLocationDisplay() {
        String loc = getLocation();
        return (loc == null || loc.isBlank()) ? "Online" : loc;
    }

    public String getShortDescription() {
        String d = getDescription();
        if (d == null) return "";
        return d.length() > 100 ? d.substring(0, 100) + "..." : d;
    }

    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", instructor='" + instructor + '\'' +
                ", price=" + price +
                ", isFree=" + isFree +
                ", status=" + status +
                ", imageUrl=" + imageUrl +
                '}';
    }
}
