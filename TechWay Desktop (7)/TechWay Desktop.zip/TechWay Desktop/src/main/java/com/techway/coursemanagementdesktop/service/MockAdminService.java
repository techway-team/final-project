package com.techway.coursemanagementdesktop.service;

public class MockAdminService {
}
